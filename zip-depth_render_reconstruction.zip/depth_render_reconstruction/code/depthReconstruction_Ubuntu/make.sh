cmake -DCMAKE_BUILD_TYPE=Release 
make