Simply extract the .zip file in the current directory
