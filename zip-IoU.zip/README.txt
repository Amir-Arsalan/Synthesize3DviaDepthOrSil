On a Windows machine, download the followings and install them:

  https://www.microsoft.com/en-us/download/details.aspx?id=48145
  https://www.microsoft.com/en-us/download/details.aspx?id=40784
  https://www.python.org/downloads/
  https://www.continuum.io/downloads

- Copy the reconstruction results into a folder named 'test'
  The structure of the folders in test is as follow:
    /test/airplane/model1-airplane
    /test/chair/model2-chair
    .
    .
    .
- Run run.bat
