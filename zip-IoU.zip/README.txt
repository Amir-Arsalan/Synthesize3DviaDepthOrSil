Install the followings
	https://www.microsoft.com/en-us/download/details.aspx?id=48145
	https://www.microsoft.com/en-us/download/details.aspx?id=40784
	https://www.python.org/downloads/
	Anaconda for Windows (to install SciPy)
Copy all .ply files into test/
Execute run.bat
