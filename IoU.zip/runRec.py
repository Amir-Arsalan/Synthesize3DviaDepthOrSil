import numpy as np
import sys
import scipy
import scipy.io as sio
import os
inputFolder = ".\\test"
outputRender = '.\\models'
os.system('mkdir ' + outputRender)
setList = os.listdir(inputFolder)
f = open('runRec.bat', 'w')
for cat in setList:
	currentModels = os.listdir(inputFolder + '\\' + cat)
	for model in currentModels:
		command = "depthReconstruction " +  "-input ./test/" + cat + '/' + model + " -output .\\models -reconstruction -resolution 224 -mask 0.2" 
		f.write(command + '\n')