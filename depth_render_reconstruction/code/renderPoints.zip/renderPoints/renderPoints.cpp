#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include "TriMesh.h"
using namespace std;
using namespace trimesh;

int main(int argc, char **argv)
{
	TriMesh *mesh;
	mesh = TriMesh::read(argv[1]);
	float y_min = 1000;
	for (size_t i = 0; i < mesh->vertices.size(); i++)
	{
		vec3 pos = mesh->vertices[i];
		if (pos[1] < y_min)
		{
			y_min = pos[1];
		}
	}
	vector<string> file_name;
	file_name.clear();
	vector<string> file_name_render;
	vector<string> file_name_render_back;
	file_name_render.clear();
	vector<int> mesh_color;
	mesh_color.clear();
	float eye_x = 1;
	float eye_y = 2;
	float eye_z = 3;
	float target_x = 0;
	float target_y = 0.0f;
	float target_z = 0.0f;
	int resolution_x = 1024;
	int resolution_y = 768;
	int move_original = 0;
	int move_share = 0;
	float colorR = 120.00 / 255;
	float colorG = 250.00 / 255;
	float colorB = 100.00 / 255;
	float radios = 0.01;


	bool flagBackFace = false;

	ifstream fin("config.txt");
	if (fin.fail() == true)
	{
		cout << "Failed to load base class parameters from config file " << "!\n";
		return 0;
	}
	string param;
	while (fin >> param)
	{
		if (param == string("FILENAME"))
		{
			string file;
			fin >> file;
			file_name.push_back(file);
		}
		else	if (param == string("EYEPOSITION"))
		{
			fin >> eye_x >> eye_y >> eye_z;
		}
		else if (param == string("TARGETPOSITION"))
		{
			fin >> target_x >> target_y >> target_z;
		}
		else if (param == string("RESOLUTION"))
		{
			fin >> resolution_x >> resolution_y;
		}
		else if (param == string("FLAG_MOVE_TO_ORIGIN"))
		{
			fin >> move_original;
		}
		else if (param == string("MOVE_SHARE_VERTEX"))
		{
			fin >> move_share;
		}
		else if (param == string("MODELRCOLOR"))
		{
			int color;
			fin >> color;
			mesh_color.push_back(color);
		}
		else if (param == string("FLAG_BACK_FACE"))
		{
			fin >> flagBackFace;
		}
		else if (param == string("POINT_COLOR"))
		{
			fin >> colorR >> colorG >> colorB;
		}
		else if (param == string("POINTRAD"))
		{
			fin >> radios;
		}
	}
	// write sc
	ofstream fout("mesh.sc");
	fout << "image {" << endl;
	fout << "      " << " resolution " << resolution_x << " " << resolution_y << endl;
	fout << "      " << " aa 0 1 " << endl;
	fout << "      " << " filter triangle" << endl;
	fout << "}" << endl;
	fout << endl;

	fout << "% |persp|perspShape " << endl;

	fout << "camera {" << endl;
	fout << "	type   pinhole" << endl;

	fout << "	eye  " << eye_x << " " << eye_y << " " << eye_z << endl;
	fout << "	target " << target_x << " " << target_y << " " << target_z << endl;
	fout << "	up     0 1 0" << endl;
	fout << "	fov    30" << endl;
	fout << "	aspect 1.3333" << endl;
	fout << "}" << endl;
	fout << endl;

	fout << "light {" << endl;
	fout << "	type sunsky" << endl;
	fout << "	up 0 1 0" << endl;
	fout << "	east 0 0 1" << endl;
	fout << "  sundir 1 1 1" << endl;
	fout << "  turbidity 4" << endl;
	fout << "  samples 64" << endl;
	fout << "}" << endl;
	fout << endl;

	fout << "shader {" << endl;
	fout << "	name simple_yelloww" << endl;
	fout << "	type diffuse" << endl;
	fout << "  diff { \"sRGB nonlinear\" 0.988 0.694 0.696  }" << endl;
	fout << "}" << endl;
	fout << endl;


	fout << "shader {" << endl;
	fout << "	name floor" << endl;
	fout << "	type constant" << endl;
	fout << " color 1 1 1" << endl;
	fout << "}" << endl;
	fout << endl;

	fout << "shader {" << endl;
	fout << "	name simple_red" << endl;
	fout << "	type diffuse" << endl;
	fout << "  diff { \"sRGB nonlinear\" 1.0 0.0 0.0 }" << endl;
	fout << "}" << endl;
	fout << endl;
	for (size_t i = 0; i < mesh->vertices.size(); i++)
	{
		fout << "shader {" << endl;
		fout << "	name simple_red_" << i << endl;
		fout << "	type diffuse" << endl;
		fout << "  diff { \"sRGB nonlinear\" ";
		fout << colorR << " " << colorG << " " << colorB << " }" << endl;
		//cout << mesh->colors[i][0] << " " <<mesh->colors[i][1] <<" "<<mesh->colors[i][2]<< " }" <<endl;
		fout << "}" << endl;
		fout << endl;

	}
	fout << "object {" << endl;
	fout << "	shader floor" << endl;
	fout << "	type plane" << endl;
	fout << " p 0  " << -5 << "  0" << endl;
	fout << " n 0 1 0" << endl;
	fout << "}" << endl;
	fout << endl;

	fout << "object {" << endl;
	fout << "	shader floor" << endl;
	fout << "	type plane" << endl;
	fout << " p -5  " << 0 << "  0" << endl;
	fout << " n 1 0 0 " << endl;
	fout << "}" << endl;
	fout << endl;

	for (size_t i = 0; i < mesh->vertices.size(); i++)
	{
		fout << "object {" << endl;
		fout << "	shader simple_red_" << i << endl;
		fout << "	 type sphere" << endl;
		fout << " name Tree_" << i << endl;
		fout << "  c " << mesh->vertices[i][0] << " " << mesh->vertices[i][1] << " " << mesh->vertices[i][2] << endl;
		fout << "  r " << radios << endl;
		fout << "}" << endl;

	}
	return 0;
}




