

for f in *.ply
do
  ./renderPoints $f
  java -jar sunflow.jar -nogui -o ${f%.*}.png mesh.sc	
done


	
